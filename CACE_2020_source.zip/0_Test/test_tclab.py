import tclab  # pip install tclab
import time
# Connect to Arduino
a = tclab.TCLab()
print('Turn on Heaters and LED')
a.Q1(30.0); a.Q2(60.0); a.LED(100)
time.sleep(10.0)
print('Display Temperatures')
print(a.T1)
print(a.T2)
a.close()

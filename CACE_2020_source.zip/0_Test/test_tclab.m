clear all
% include tclab.m
tclab;
disp('Turn on Heaters and LED')
h1(30);  h2(60); led(1);
pause(10)
disp('Display Temperatures')
disp(T1C())
disp(T2C())
h1(0);  h2(0); led(0);
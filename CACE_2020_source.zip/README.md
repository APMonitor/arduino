Source files for the article:

Park, J., Martin, R.A., Kelly, J.D., Hedengren, J.D., Benchmark Temperature Microcontroller for Process Dynamics and Control, Computers & Chemical Engineering, Special Issue in Honor of Tom Edgar's 75th birthday, vol. 135, 2020, DOI: https://doi.org/10.1016/j.compchemeng.2020.106736

https://www.sciencedirect.com/science/article/pii/S0098135419310129

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from gekko import GEKKO

#########################################################
# Initialize Model
#########################################################
# load data and parse into columns
url = 'initial_models.csv'
data = pd.read_csv(url)
t = data['Time']
u = data[['H1','H2']]
y = data[['T1','T2']]

# generate time-series model
m = GEKKO(remote=False)

##################################################################
# system identification
na = 2 # output coefficients
nb = 2 # input coefficients
print('Identify model')
yp,p,K = m.sysid(t,u,y,na,nb,objf=10000,scale=False,diaglevel=1,pred='model')

##################################################################
# plot sysid results
plt.figure(figsize=(10,7))
plt.subplot(2,1,1)
plt.plot(t,data['H1'],'r-')
plt.plot(t,data['H2'],'g:')
plt.legend([r'$Q_1$',r'$Q_2$'])
plt.ylabel('MVs')
plt.subplot(2,1,2)
plt.plot(t,data['T1'],'r.')
plt.plot(t,yp[:,0],'k--',lw=2)
plt.plot(t,data['T2'],'.',color='orange')
plt.plot(t,yp[:,1],'k:',lw=2)
plt.legend([r'$T_{C1,meas}$',r'$T_{C1,pred}$',\
            r'$T_{C2,meas}$',r'$T_{C2,pred}$'])
plt.ylabel('CVs')
plt.xlabel('Time (sec)')
plt.savefig('tclab_farxid.png')
plt.savefig('tclab_farxid.eps')
plt.show()


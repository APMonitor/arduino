test_models.py runs a real-time plot with 2 models and generates initial_models.csv (as does gen_data.py)
tclab_fopdt.py fits an FOPDT with initial_models.csv data
tclab_estimate.py fits to initial_models.csv by adjusting physics-based model parameters and displays FOPDT fit
tclab_arx.py fits 2nd order ARX model with initial_models.csv data



import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from gekko import GEKKO
from scipy.integrate import odeint
from scipy.interpolate import interp1d

# Import or generate data
filename = 'initial_models.csv'
data = pd.read_csv(filename)

# FOPDT Model from tclab_fopdt.py
p0 = np.zeros(3)
p0[0] = 0.925  #0.920  # Km
p0[1] = 167.06 #175.18 # taum
p0[2] = 13.72  #15.62  # thetam

t = data['Time'].values - data['Time'].values[0]
u0 = data['H1'].values[0]
yp0 = data['T1'].values[0]
u = data['H1'].values
yp = data['T1'].values
# specify number of steps
ns = len(t)
delta_t = t[1]-t[0]
# create linear interpolation of the u data versus time
uf = interp1d(t,u)

# define first-order plus dead-time approximation    
def fopdt(y,t,uf,Km,taum,thetam):
    # arguments
    #  y      = output
    #  t      = time
    #  uf     = input linear function (for time shift)
    #  Km     = model gain
    #  taum   = model time constant
    #  thetam = model time constant
    # time-shift u
    try:
        if (t-thetam) <= 0:
            um = uf(0.0)
        else:
            um = uf(t-thetam)
    except:
        #print('Error with time extrapolation: ' + str(t))
        um = u0
    # calculate derivative
    dydt = (-(y-yp0) + Km * (um-u0))/taum
    return dydt

# simulate FOPDT model with x=[Km,taum,thetam]
def sim_model(x):
    # input arguments
    Km = x[0]
    taum = x[1]
    thetam = x[2]
    # storage for model values
    ym = np.zeros(ns)  # model
    # initial condition
    ym[0] = yp0
    # loop through time steps    
    for i in range(0,ns-1):
        ts = [t[i],t[i+1]]
        y1 = odeint(fopdt,ym[i],ts,args=(uf,Km,taum,thetam))
        ym[i+1] = y1[-1]
    return ym

yfopdt = sim_model(p0)

# Fit Parameters of Energy Balance
# Create GEKKO Models
m = GEKKO() # fit
v = GEKKO() # validate

for x in [m,v]:
    # Parameters to Estimate
    x.U = x.FV(value=10,lb=1,ub=20)
    x.Us = x.FV(value=20,lb=5,ub=40)
    x.alpha1 = x.FV(value=0.01,lb=0.001,ub=0.03)  # W / % heater
    x.alpha2 = x.FV(value=0.005,lb=0.001,ub=0.02) # W / % heater
    x.tau = x.FV(value=10.0,lb=5.0,ub=60.0)

    # Measured inputs
    x.Q1 = x.MV()
    x.Q2 = x.MV()

    Ta =23.0+273.15                     # K
    mass = 4.0/1000.0                   # kg
    Cp = 0.5*1000.0                     # J/kg-K    
    A = 10.0/100.0**2                   # Area not between heaters in m^2
    As = 2.0/100.0**2                   # Area between heaters in m^2
    eps = 0.9                           # Emissivity
    sigma = 5.67e-8                     # Stefan-Boltzmann

    x.TH1 = x.SV()
    x.TH2 = x.SV()
    x.TC1 = x.CV()
    x.TC2 = x.CV()

    # Heater Temperatures in Kelvin
    x.T1 = x.Intermediate(x.TH1+273.15)
    x.T2 = x.Intermediate(x.TH2+273.15)

    # Heat transfer between two heaters
    x.Q_C12 = x.Intermediate(x.Us*As*(x.T2-x.T1)) # Convective
    x.Q_R12 = x.Intermediate(eps*sigma*As*(x.T2**4-x.T1**4)) # Radiative

    # Energy balances
    x.Equation(x.TH1.dt() == (1.0/(mass*Cp))*(x.U*A*(Ta-x.T1) \
                    + eps * sigma * A * (Ta**4 - x.T1**4) \
                    + x.Q_C12 + x.Q_R12 \
                    + x.alpha1*x.Q1))

    x.Equation(x.TH2.dt() == (1.0/(mass*Cp))*(x.U*A*(Ta-x.T2) \
                    + eps * sigma * A * (Ta**4 - x.T2**4) \
                    - x.Q_C12 - x.Q_R12 \
                    + x.alpha2*x.Q2))

    # Conduction to temperature sensors
    x.Equation(x.tau*x.TC1.dt() == x.TH1-x.TC1)
    x.Equation(x.tau*x.TC2.dt() == x.TH2-x.TC2)

# Options
# STATUS=1 allows solver to adjust parameter
m.U.STATUS = 1  
m.Us.STATUS = 1  
m.alpha1.STATUS = 1 
m.alpha2.STATUS = 1
m.tau.STATUS = 1

m.Q1.value=data['H1'].values
m.Q2.value=data['H2'].values
m.TH1.value=data['T1'].values[0]
m.TH2.value=data['T2'].values[0]
m.TC1.value=data['T1'].values
m.TC1.FSTATUS = 1    # minimize fstatus * (meas-pred)^2
m.TC2.value=data['T2'].values
m.TC2.FSTATUS = 1    # minimize fstatus * (meas-pred)^2

m.time = data['Time'].values
m.options.IMODE   = 5 # MHE
m.options.EV_TYPE = 2 # Objective type
m.options.NODES   = 2 # Collocation nodes
m.options.SOLVER  = 3 # IPOPT

# Solve
m.solve(disp=True)

# Parameter values
print('U     : ' + str(m.U.value[0]))
print('Us     : ' + str(m.Us.value[0]))
print('alpha1: ' + str(m.alpha1.value[0]))
print('alpha2: ' + str(m.alpha2.value[-1]))
print('tau: ' + str(m.tau.value[0]))

sae1 = 0.0
sae2 = 0.0
for i in range(len(data)):
    sae1 += np.abs(data['T1'][i]-m.TC1.value[i])
    sae1 += np.abs(data['T2'][i]-m.TC2.value[i])
    sae2 += np.abs(data['T1'][i]-yfopdt[i])
print('SAE Energy Balance: ' + str(sae1))
print('SAE FOPDT: ' + str(sae2))

# Create plot
plt.figure(figsize=(10,7))
ax=plt.subplot(2,1,1)
ax.grid()
plt.plot(data['Time'],data['T1'],'r.',label=r'$T_1$ measured')
plt.plot(m.time,m.TC1.value,color='black',linestyle='--',\
         linewidth=2,label=r'$T_1$ energy balance')
plt.plot(t,yfopdt,color='gray',linestyle=':',\
         linewidth=2,label=r'$T_1$ FOPDT')
plt.plot(data['Time'],data['T2'],'b.',label=r'$T_2$ measured')
plt.plot(m.time,m.TC2.value,color='orange',linestyle='--',\
         linewidth=2,label=r'$T_2$ energy balance')
plt.ylabel(r'T ($^oC$)')
plt.legend(loc=2)
ax=plt.subplot(2,1,2)
ax.grid()
plt.plot(data['Time'],data['H1'],'r-',\
         linewidth=3,label=r'$Q_1$')
plt.plot(data['Time'],data['H2'],'b:',\
         linewidth=3,label=r'$Q_2$')
plt.ylabel('Heaters')
plt.xlabel('Time (sec)')
plt.legend(loc='best')
plt.savefig('tclab_estimate.png')
plt.savefig('tclab_estimate.eps')


# Load validation data
filename = 'validation.csv'
data = pd.read_csv(filename)

# FOPDT model
t = data['Time'].values - data['Time'].values[0]
u0 = data['H1'].values[0]
yp0 = data['T1'].values[0]
u = data['H1'].values
yp = data['T1'].values
# specify number of steps
ns = len(t)
delta_t = t[1]-t[0]
# create linear interpolation of the u data versus time
uf = interp1d(t,u)
yfopdt = sim_model(p0)

# Energy Balance
v.time = data['Time'].values
v.Q1.value = data['H1'].values
v.Q2.value = data['H2'].values
v.TH1.value=data['T1'].values[0]
v.TH2.value=data['T2'].values[0]
v.TC1.value=data['T1'].values[0]
v.TC2.value=data['T2'].values[0]
# transfer parameters
# Parameter values
v.U.value = m.U.value[0]
v.Us.value = m.Us.value[0]
v.alpha1.value = m.alpha1.value[0]
v.alpha2.value = m.alpha2.value[0]
v.tau.value = m.tau.value[0]
v.options.IMODE = 4
v.solve(disp=False)

# Create plot
plt.figure(figsize=(10,7))
ax=plt.subplot(2,1,1)
ax.grid()
plt.plot(data['Time'],data['T1'],'r.',label=r'$T_1$ measured')
plt.plot(v.time,v.TC1.value,color='black',linestyle='--',\
         linewidth=2,label=r'$T_1$ energy balance')
plt.plot(t,yfopdt,color='gray',linestyle=':',\
         linewidth=2,label=r'$T_1$ FOPDT')
plt.plot(data['Time'],data['T2'],'b.',label=r'$T_2$ measured')
plt.plot(v.time,v.TC2.value,color='orange',linestyle='--',\
         linewidth=2,label=r'$T_2$ energy balance')
plt.ylabel(r'T ($^oC$)')
plt.legend(loc=2)
ax=plt.subplot(2,1,2)
ax.grid()
plt.plot(data['Time'],data['H1'],'r-',\
         linewidth=3,label=r'$Q_1$')
plt.plot(data['Time'],data['H2'],'b:',\
         linewidth=3,label=r'$Q_2$')
plt.ylabel('Heaters')
plt.xlabel('Time (sec)')
plt.legend(loc='best')
plt.savefig('tclab_estimate_validation.png')
plt.savefig('tclab_estimate_validation.eps')

sae1 = 0.0
sae2 = 0.0
for i in range(len(data)):
    sae1 += np.abs(data['T1'][i]-v.TC1.value[i])
    sae1 += np.abs(data['T2'][i]-v.TC2.value[i])
    sae2 += np.abs(data['T1'][i]-yfopdt[i])
print('Validation')
print('SAE Energy Balance: ' + str(sae1))
print('SAE FOPDT: ' + str(sae2))

plt.show()

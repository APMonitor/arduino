import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from gekko import GEKKO

#########################################################
# Initialize Model
#########################################################
# load data and parse into columns
data = pd.read_csv('data.txt')
t = data['Time']
u = data[['Q1','Q2']]
y = data[['T1','T2']]

# generate time-series model
m = GEKKO(remote=False)

##################################################################
# system identification
na = 2 # output coefficients
nb = 2 # input coefficients
print('Identify model')
yp,p,K = m.sysid(t,u,y,na,nb,objf=10000,scale=False,diaglevel=1,pred='model')


mv_obj = 0.0
for i in range(1,len(t)):
    mv_obj += np.abs(data['Q1'][i] - data['Q1'][i-1])
cv_obj = np.sum(np.abs(data['TSP1'].values-data['T1'].values))
total_obj = (cv_obj + 0.5*mv_obj)/len(t)
print('Average IAE Objective: ' + str(total_obj))
 
##################################################################
# plot sysid results
plt.figure(figsize=(10,7))
plt.subplot(2,1,1)
plt.plot(t,data['Q1'],'r-')
plt.plot(t,data['Q2'],'g:')
plt.legend([r'$Q_1$',r'$Q_2$'],loc=1)
plt.ylabel('MVs')
plt.subplot(2,1,2)
plt.plot(t,data['TSP1'],'k-')
plt.plot(t,data['T1'],'r.')
plt.plot(t,yp[:,0],'k--',lw=2)
plt.plot(t,data['TSP2'],'k:')
plt.plot(t,data['T2'],'.',color='orange')
plt.plot(t,yp[:,1],'k:',lw=2)
plt.legend([r'$T_{SP1}$','$T_{C1,meas}$',r'$T_{C1,pred}$',\
            r'$T_{SP2}$','$T_{C2,meas}$',r'$T_{C2,pred}$'],loc=4)
plt.ylabel('CVs')
plt.xlabel('Time (sec)')
plt.savefig('tclab_farxid.png')
plt.savefig('tclab_farxid.eps')
plt.show()


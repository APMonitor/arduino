import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from gekko import GEKKO

#########################################################
# Initialize Model
#########################################################
# load data and parse into columns
data = pd.read_csv('validate.txt')
t = data['Time']
u = data[['Q1','Q2']]
y = data[['T1','T2']]

mv_obj = 0.0
for i in range(1,len(t)):
    mv_obj += np.abs(data['Q1'][i] - data['Q1'][i-1])
cv_obj = np.sum(np.abs(data['TSP1'].values-data['T1'].values))
total_obj = (cv_obj + 0.5*mv_obj)/len(t)
print('Average IAE Objective: ' + str(total_obj))

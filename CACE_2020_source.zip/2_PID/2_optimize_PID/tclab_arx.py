import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from gekko import GEKKO

#########################################################
# Initialize Model
#########################################################
# load data and parse into columns
data = pd.read_csv('data.txt')
t = data['Time']
u = data[['Q1','Q2']]
y = data[['T1','T2']]

# generate time-series model
m = GEKKO(remote=False)

##################################################################
# system identification
na = 2 # output coefficients
nb = 2 # input coefficients
print('Identify model')
yp,p,K = m.sysid(t,u,y,na,nb,objf=10000,shift='init',\
                 scale=False,diaglevel=1,pred='model')

##################################################################
# PID simulation
# FOPDT Model
Kp = 0.9200270657559153
tauP = 175.1814480958061
thetaP = 15.622280726988599

# Aggressive IMC Controller (PI control)
tauC = max(0.1*tauP,0.8*thetaP)
Kc   = tauP/(Kp*(thetaP+tauC))
tauI = tauP # sec
tauD = 0.0  # sec

######################################################
# PID Controller                                     #
######################################################
# inputs -----------------------------------
# sp = setpoint
# pv = current temperature
# pv_last = prior temperature
# ierr = integral error
# dt = time increment between measurements
# outputs ----------------------------------
# op = output of the PID controller
# P = proportional contribution
# I = integral contribution
# D = derivative contribution
def pid(sp,pv,pv_last,ierr,dt,Kc,tauI,tauD):
    # Parameters in terms of PID coefficients
    KP = Kc
    KI = Kc/tauI
    KD = Kc*tauD
    # ubias for controller (initial heater)
    op0 = 0 
    # upper and lower bounds on heater level
    ophi = 100
    oplo = 0
    # calculate the error
    error = sp-pv
    # calculate the integral error
    ierr = ierr + KI * error * dt
    # calculate the measurement derivative
    dpv = (pv - pv_last) / dt
    # calculate the PID output
    P = KP * error
    I = ierr
    D = -KD * dpv
    op = op0 + P + I + D
    # implement anti-reset windup
    if op < oplo or op > ophi:
        I = I - KI * error * dt
        # clip output
        op = max(oplo,min(ophi,op))
    # return the controller output and PID terms
    return [op,P,I,D]

loops = len(t)
dt = 1.0
ierr = 0.0
Q1 = np.ones(loops) * 0.0
Q2 = np.ones(loops) * 0.0
T1 = np.ones(loops) * data['T1'][0] # simulated T (degC)
T2 = np.ones(loops) * data['T2'][0] # simulated T (degC)
Tsp1 = data['TSP1'].values
Tsp2 = data['TSP2'].values
m = GEKKO(remote=False)
y,u = m.arx(p)
m.time = [0,1]
m.options.IMODE = 1
m.solve()
m.options.IMODE = 4
m.solve()
for i in range(loops):
    [Q1[i],P,ierr,D] = pid(Tsp1[i],T1[i],T1[i-1],ierr,dt,Kc,tauI,tauD)
    u[0].value = Q1[i]
    m.solve(disp=False)
    if i<loops-1:
        T1[i+1] = y[0].value[1]
        T2[i+1] = y[1].value[1]

##################################################################
# plot sysid results
plt.figure(figsize=(10,7))
plt.subplot(2,1,1)
plt.plot(t,data['Q1'],'r-')
plt.plot(t,Q1,'r:')
plt.plot(t,data['Q2'],'b-')
plt.plot(t,Q2,'b:')
plt.legend([r'$Q_1$ Original',r'$Q_1$ Optimal',\
            r'$Q_2$ Original',r'$Q_2$ Optimal'],loc=1)
plt.ylabel('MVs')
plt.subplot(2,1,2)
plt.plot(t,data['TSP1'],'k-')
plt.plot(t,data['T1'],'r.')
plt.plot(t,T1,'r:')
plt.plot(t,yp[:,0],'k--',lw=2)
plt.plot(t,data['TSP2'],'k:')
plt.plot(t,data['T2'],'.',color='orange')
plt.plot(t,T2,':',color='orange')
plt.plot(t,yp[:,1],'k:',lw=2)
plt.legend([r'$T_{SP1}$','$T_{C1,meas}$',\
            r'$T_{C1,optimal}$',r'$T_{C1,pred}$',\
            r'$T_{SP2}$','$T_{C2,meas}$',\
            r'$T_{C2,optimal}$',r'$T_{C2,pred}$'],loc=4)
plt.ylabel('CVs')
plt.xlabel('Time (sec)')
plt.savefig('tclab_farxid.png')
plt.savefig('tclab_farxid.eps')
plt.show()






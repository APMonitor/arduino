# FOPDT Model
Kp = 0.9200270657559153
tauP = 175.1814480958061
thetaP = 15.622280726988599

# Aggressive IMC Controller (PI control)
tauC = max(0.1*tauP,0.8*thetaP)
Kc   = tauP/(Kp*(thetaP+tauC))
tauI = tauP # sec
tauD = 0.0  # sec


print(Kc)
print(tauI)
print(tauD)
